
     <div id="severs_nav">
               
        
               
              
              
                <?php  ob_start(); wp_nav_menu(array('walker' => new header_menu(), 'container' => false,'theme_location' => 'drogz-menu','items_wrap' => '<div class="severs_nav_ul">%3$s</div>' ) ); ?>
               
               
               

               

           
          </div>
          
          