<?php get_header();

?>
<div class="content" id="index_content">

<?php dynamic_sidebar('index_content');?>
</div>
<?php get_footer(); ?>
