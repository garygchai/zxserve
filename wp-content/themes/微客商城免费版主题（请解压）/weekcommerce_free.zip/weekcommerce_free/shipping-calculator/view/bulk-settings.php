<div class="inline-edit-group shipping-calculator-field">
    <label class="shipping-calculator-field-enable">
        <span class="title"><?php echo __('Hide Shipping Calculator?', 'rphpa_hide_calculator'); ?></span>
        <input type="checkbox" value="1" name="<?php echo self::$calculator_metakey; ?>"><br>
    </label>
</div>