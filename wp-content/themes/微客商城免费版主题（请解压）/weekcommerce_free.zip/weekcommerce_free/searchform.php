<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
    <div>
    </div>  
        <input type="text" id="s" name="s" value="" />
        
      

</form>