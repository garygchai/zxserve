<?php
/* 初始化设置*/

function woo_language_option_function(){





	if($_POST['post_velue']) {
		if($_POST['Submitxx']) {
	$woo_language_wh1 = trim($_POST['woo_language_wh1']);
	$woo_language_wh3 = trim($_POST['woo_language_wh3']);
	$woo_language_wh4 = trim($_POST['woo_language_wh4']);
	$woo_language_wh5 = trim($_POST['woo_language_wh5']);


	}
		
	
		
	if($_POST['Submit1']) {
	$woo_language_l1  = trim($_POST['woo_language_l1']);
	$woo_language_l2  = trim($_POST['woo_language_l2']);
	$woo_language_l3  = trim($_POST['woo_language_l3']);
	$woo_language_l4  = trim($_POST['woo_language_l4']);
	$woo_language_l5  = trim($_POST['woo_language_l5']);
	$woo_language_l6  = trim($_POST['woo_language_l6']);
	$woo_language_l7  = trim($_POST['woo_language_l7']);
	$woo_language_l8  = trim($_POST['woo_language_l8']);
	}
	if($_POST['Submit2']) {
	$woo_language_r1  = trim($_POST['woo_language_r1']);
	$woo_language_r2  = trim($_POST['woo_language_r2']);
	$woo_language_r3  = trim($_POST['woo_language_r3']);
	$woo_language_r4  = trim($_POST['woo_language_r4']);
	}
	if($_POST['Submit3']) {
	$woo_language_f1  = trim($_POST['woo_language_f1']);
	$woo_language_f2  = trim($_POST['woo_language_f2']);
	$woo_language_f3  = trim($_POST['woo_language_f3']);
	$woo_language_f4  = trim($_POST['woo_language_f4']);
	$woo_language_f5  = trim($_POST['woo_language_f5']);
	$woo_language_f6  = trim($_POST['woo_language_f6']);
	$woo_language_f7  = trim($_POST['woo_language_f7']);
	$woo_language_f8  = trim($_POST['woo_language_f8']);
	}
	if($_POST['Submit4']) {
	$woo_language_p1  = trim($_POST['woo_language_p1']);
	$woo_language_p2  = trim($_POST['woo_language_p2']);
	$woo_language_p3  = trim($_POST['woo_language_p3']);
	$woo_language_p4  = trim($_POST['woo_language_p4']);
	$woo_language_p5  = trim($_POST['woo_language_p5']);
	$woo_language_p6  = trim($_POST['woo_language_p6']);
	$woo_language_p7  = trim($_POST['woo_language_p7']);
	}if($_POST['Submit5']) {
	
	$woo_language_d1  = trim($_POST['woo_language_d1']);
	$woo_language_d2  = trim($_POST['woo_language_d2']);
	$woo_language_d3  = trim($_POST['woo_language_d3']);
	$woo_language_d4  = trim($_POST['woo_language_d4']);
	$woo_language_d5  = trim($_POST['woo_language_d5']);
	$woo_language_d6  = trim($_POST['woo_language_d6']);
	$woo_language_d7  = trim($_POST['woo_language_d7']);
	$woo_language_d8  = trim($_POST['woo_language_d8']);
	$woo_language_d9  = trim($_POST['woo_language_d9']);
	$woo_language_d0  = trim($_POST['woo_language_d0']);
	$woo_language_d11  = trim($_POST['woo_language_d11']);
	$woo_language_d12  = trim($_POST['woo_language_d12']);
	}
	if($_POST['Submit6']) {
	$woo_language_ds1  = trim($_POST['woo_language_ds1']);
	$woo_language_ds2  = trim($_POST['woo_language_ds2']);
	$woo_language_ds3  = trim($_POST['woo_language_ds3']);
	$woo_language_ds4  = trim($_POST['woo_language_ds4']);
	$woo_language_ds5  = trim($_POST['woo_language_ds5']);
	$woo_language_ds6  = trim($_POST['woo_language_ds6']);
	
	}
	if($_POST['Submit7']) {
	$woo_language_dz1  = trim($_POST['woo_language_dz1']);
	$woo_language_dz2  = trim($_POST['woo_language_dz2']);
	$woo_language_dz3  = trim($_POST['woo_language_dz3']);
	$woo_language_dz4  = trim($_POST['woo_language_dz4']);
	$woo_language_dz5  = trim($_POST['woo_language_dz5']);
	$woo_language_dz6  = trim($_POST['woo_language_dz6']);
	$woo_language_dz7  = trim($_POST['woo_language_dz7']);
	$woo_language_dz8  = trim($_POST['woo_language_dz8']);
	$woo_language_dz9  = trim($_POST['woo_language_dz9']);
	$woo_language_dz0  = trim($_POST['woo_language_dz0']);
	$woo_language_dz11  = trim($_POST['woo_language_dz11']);
	$woo_language_dz12  = trim($_POST['woo_language_dz12']);
	$woo_language_dz13  = trim($_POST['woo_language_dz13']);
	$woo_language_dz14  = trim($_POST['woo_language_dz14']);
	$woo_language_dz15  = trim($_POST['woo_language_dz15']);
	$woo_language_dz16  = trim($_POST['woo_language_dz16']);
	$woo_language_dz17  = trim($_POST['woo_language_dz17']);
	$woo_language_dz18  = trim($_POST['woo_language_dz18']);
	}
	
	if($_POST['Submit8']) {
		$woo_language_or1  = trim($_POST['woo_language_or1']);
		$woo_language_or2  = trim($_POST['woo_language_or2']);
		$woo_language_or3  = trim($_POST['woo_language_or3']);
		$woo_language_or4  = trim($_POST['woo_language_or4']);
		$woo_language_or5  = trim($_POST['woo_language_or5']);
		$woo_language_or6  = trim($_POST['woo_language_or6']);
		$woo_language_or7  = trim($_POST['woo_language_or7']);
		$woo_language_or8  = trim($_POST['woo_language_or8']);
		$woo_language_or9  = trim($_POST['woo_language_or9']);
		
	}
	
	if($_POST['Submit9']) {
		$woo_language_a1  = trim($_POST['woo_language_a1']);
		$woo_language_a2  = trim($_POST['woo_language_a2']);
		$woo_language_a3  = trim($_POST['woo_language_a3']);
		$woo_language_a4  = trim($_POST['woo_language_a4']);
		$woo_language_a5  = trim($_POST['woo_language_a5']);
		$woo_language_a6  = trim($_POST['woo_language_a6']);
		$woo_language_a7  = trim($_POST['woo_language_a7']);
		$woo_language_a8  = trim($_POST['woo_language_a8']);
		$woo_language_a9  = trim($_POST['woo_language_a9']);

		
	}
	
	
	if($_POST['Submit0']) {
		$woo_language_cart1  = trim($_POST['woo_language_cart1']);
		$woo_language_cart2  = trim($_POST['woo_language_cart2']);
		$woo_language_cart3  = trim($_POST['woo_language_cart3']);
		$woo_language_cart4  = trim($_POST['woo_language_cart4']);
		$woo_language_cart5  = trim($_POST['woo_language_cart5']);
		$woo_language_cart6  = trim($_POST['woo_language_cart6']);
		$woo_language_cart7  = trim($_POST['woo_language_cart7']);
		$woo_language_cart8  = trim($_POST['woo_language_cart8']);
		$woo_language_cart9  = trim($_POST['woo_language_cart9']);
		$woo_language_cart0  = trim($_POST['woo_language_cart0']);
		
		
		
	}
	
	if($_POST['Submit11']) {
		$woo_language_carts1  = trim($_POST['woo_language_carts1']);
		$woo_language_carts2  = trim($_POST['woo_language_carts2']);
		$woo_language_carts3  = trim($_POST['woo_language_carts3']);
		$woo_language_carts4  = trim($_POST['woo_language_carts4']);
		$woo_language_carts5  = trim($_POST['woo_language_carts5']);
		$woo_language_carts6  = trim($_POST['woo_language_carts6']);
		$woo_language_carts7  = trim($_POST['woo_language_carts7']);
		$woo_language_carts8  = trim($_POST['woo_language_carts8']);
		$woo_language_carts9  = trim($_POST['woo_language_carts9']);
		$woo_language_carts0  = trim($_POST['woo_language_carts0']);
		$woo_language_carts11  = trim($_POST['woo_language_carts11']);
		$woo_language_carts12  = trim($_POST['woo_language_carts12']);
		
		
	}
	
	
	
	
	
	$update_main_queries = array();
	$update_main_text    = array();
	if($_POST['Submitxx']) {
		$update_main_queries[] = update_option('woo_language_wh1', $woo_language_wh1);
		$update_main_queries[] = update_option('woo_language_wh3', $woo_language_wh3);
		$update_main_queries[] = update_option('woo_language_wh4', $woo_language_wh4);
		$update_main_queries[] = update_option('woo_language_wh5', $woo_language_wh5);
		}
	if($_POST['Submit1']) {
	$update_main_queries[] = update_option('woo_language_l1', $woo_language_l1);
	$update_main_queries[] = update_option('woo_language_l2', $woo_language_l2);
	$update_main_queries[] = update_option('woo_language_l3', $woo_language_l3);
	$update_main_queries[] = update_option('woo_language_l4', $woo_language_l4);
	$update_main_queries[] = update_option('woo_language_l5', $woo_language_l5);
	$update_main_queries[] = update_option('woo_language_l6', $woo_language_l6);
	$update_main_queries[] = update_option('woo_language_l7', $woo_language_l7);
	$update_main_queries[] = update_option('woo_language_l8', $woo_language_l8);
	}if($_POST['Submit2']) {
	$update_main_queries[] = update_option('woo_language_r1', $woo_language_r1); 
	$update_main_queries[] = update_option('woo_language_r2', $woo_language_r2); 
	$update_main_queries[] = update_option('woo_language_r3', $woo_language_r3); 
	$update_main_queries[] = update_option('woo_language_r4', $woo_language_r4); 
    	}if($_POST['Submit3']) {
	$update_main_queries[] = update_option('woo_language_f1', $woo_language_f1); 
	$update_main_queries[] = update_option('woo_language_f2', $woo_language_f2);
	$update_main_queries[] = update_option('woo_language_f3', $woo_language_f3);
	$update_main_queries[] = update_option('woo_language_f4', $woo_language_f4);
	$update_main_queries[] = update_option('woo_language_f5', $woo_language_f5);
	$update_main_queries[] = update_option('woo_language_f6', $woo_language_f6);
	$update_main_queries[] = update_option('woo_language_f7', $woo_language_f7);
	$update_main_queries[] = update_option('woo_language_f8', $woo_language_f8);
		}if($_POST['Submit4']) {
	$update_main_queries[] = update_option('woo_language_p1', $woo_language_p1);
	$update_main_queries[] = update_option('woo_language_p2', $woo_language_p2);
	$update_main_queries[] = update_option('woo_language_p3', $woo_language_p3);
	$update_main_queries[] = update_option('woo_language_p4', $woo_language_p4);
	$update_main_queries[] = update_option('woo_language_p5', $woo_language_p5);
	$update_main_queries[] = update_option('woo_language_p6', $woo_language_p6);
	$update_main_queries[] = update_option('woo_language_p7', $woo_language_p7);
		}if($_POST['Submit5']) {
	$update_main_queries[] = update_option('woo_language_d1', $woo_language_d1);
	$update_main_queries[] = update_option('woo_language_d2', $woo_language_d2);
	$update_main_queries[] = update_option('woo_language_d3', $woo_language_d3);
	$update_main_queries[] = update_option('woo_language_d4', $woo_language_d4);
	$update_main_queries[] = update_option('woo_language_d5', $woo_language_d5);
	$update_main_queries[] = update_option('woo_language_d6', $woo_language_d6);
	$update_main_queries[] = update_option('woo_language_d7', $woo_language_d7);
	$update_main_queries[] = update_option('woo_language_d8', $woo_language_d8);
	$update_main_queries[] = update_option('woo_language_d9', $woo_language_d9);
	$update_main_queries[] = update_option('woo_language_d0', $woo_language_d0);
	$update_main_queries[] = update_option('woo_language_d11', $woo_language_d11);
	$update_main_queries[] = update_option('woo_language_d12', $woo_language_d12);
		}if($_POST['Submit6']) {
	$update_main_queries[] = update_option('woo_language_ds1', $woo_language_ds1);
	$update_main_queries[] = update_option('woo_language_ds2', $woo_language_ds2);
	$update_main_queries[] = update_option('woo_language_ds3', $woo_language_ds3);
	$update_main_queries[] = update_option('woo_language_ds4', $woo_language_ds4);  
	$update_main_queries[] = update_option('woo_language_ds5', $woo_language_ds5);
	$update_main_queries[] = update_option('woo_language_ds6', $woo_language_ds6);  
	}if($_POST['Submit7']) {
	$update_main_queries[] = update_option('woo_language_dz1', $woo_language_dz1);
	$update_main_queries[] = update_option('woo_language_dz2', $woo_language_dz2);
	$update_main_queries[] = update_option('woo_language_dz3', $woo_language_dz3);
	$update_main_queries[] = update_option('woo_language_dz4', $woo_language_dz4);
	$update_main_queries[] = update_option('woo_language_dz5', $woo_language_dz5);
	$update_main_queries[] = update_option('woo_language_dz6', $woo_language_dz6);
	$update_main_queries[] = update_option('woo_language_dz7', $woo_language_dz7);
	$update_main_queries[] = update_option('woo_language_dz8', $woo_language_dz8);
	$update_main_queries[] = update_option('woo_language_dz9', $woo_language_dz9);
	$update_main_queries[] = update_option('woo_language_dz0', $woo_language_dz0);
	$update_main_queries[] = update_option('woo_language_dz11', $woo_language_dz11);
	$update_main_queries[] = update_option('woo_language_dz12', $woo_language_dz12);
	$update_main_queries[] = update_option('woo_language_dz13', $woo_language_dz13);
	$update_main_queries[] = update_option('woo_language_dz14', $woo_language_dz14);
	$update_main_queries[] = update_option('woo_language_dz15', $woo_language_dz15);
	$update_main_queries[] = update_option('woo_language_dz16', $woo_language_dz16);
	$update_main_queries[] = update_option('woo_language_dz17', $woo_language_dz17);
	$update_main_queries[] = update_option('woo_language_dz18', $woo_language_dz18);
	}if($_POST['Submit8']) {
	$update_main_queries[] = update_option('woo_language_or1', $woo_language_or1);
	$update_main_queries[] = update_option('woo_language_or2', $woo_language_or2);
	$update_main_queries[] = update_option('woo_language_or3', $woo_language_or3);
	$update_main_queries[] = update_option('woo_language_or4', $woo_language_or4);
	$update_main_queries[] = update_option('woo_language_or5', $woo_language_or5);
	$update_main_queries[] = update_option('woo_language_or6', $woo_language_or6);
	$update_main_queries[] = update_option('woo_language_or7', $woo_language_or7);
	$update_main_queries[] = update_option('woo_language_or8', $woo_language_or8);
    $update_main_queries[] = update_option('woo_language_or9', $woo_language_or9);
	
	}
	 if($_POST['Submit9']) {
	$update_main_queries[] = update_option('woo_language_a1', $woo_language_a1);
	$update_main_queries[] = update_option('woo_language_a2', $woo_language_a2);
	$update_main_queries[] = update_option('woo_language_a3', $woo_language_a3);
	$update_main_queries[] = update_option('woo_language_a4', $woo_language_a4);
	$update_main_queries[] = update_option('woo_language_a5', $woo_language_a5);
	$update_main_queries[] = update_option('woo_language_a6', $woo_language_a6);
	$update_main_queries[] = update_option('woo_language_a7', $woo_language_a7);
	$update_main_queries[] = update_option('woo_language_a8', $woo_language_a8);
	$update_main_queries[] = update_option('woo_language_a9', $woo_language_a9);
	
	
	}  if($_POST['Submit0']) {
	$update_main_queries[] = update_option('woo_language_cart1', $woo_language_cart1);
	$update_main_queries[] = update_option('woo_language_cart2', $woo_language_cart2);
	$update_main_queries[] = update_option('woo_language_cart3', $woo_language_cart3);
	$update_main_queries[] = update_option('woo_language_cart4', $woo_language_cart4);
    $update_main_queries[] = update_option('woo_language_cart5', $woo_language_cart5);
	$update_main_queries[] = update_option('woo_language_cart6', $woo_language_cart6);
	$update_main_queries[] = update_option('woo_language_cart7', $woo_language_cart7);
	$update_main_queries[] = update_option('woo_language_cart8', $woo_language_cart8);
	$update_main_queries[] = update_option('woo_language_cart9', $woo_language_cart9);
	$update_main_queries[] = update_option('woo_language_cart0', $woo_language_cart0);
	

	} 
	
	if($_POST['Submit11']) {
	$update_main_queries[] = update_option('woo_language_carts1', $woo_language_carts1);
	$update_main_queries[] = update_option('woo_language_carts2', $woo_language_carts2);
	$update_main_queries[] = update_option('woo_language_carts3', $woo_language_carts3);
	$update_main_queries[] = update_option('woo_language_carts4', $woo_language_carts4);
    $update_main_queries[] = update_option('woo_language_carts5', $woo_language_carts5);
	$update_main_queries[] = update_option('woo_language_carts6', $woo_language_carts6);
	$update_main_queries[] = update_option('woo_language_carts7', $woo_language_carts7);
	$update_main_queries[] = update_option('woo_language_carts8', $woo_language_carts8);
	$update_main_queries[] = update_option('woo_language_carts9', $woo_language_carts9);
	$update_main_queries[] = update_option('woo_language_carts0', $woo_language_carts0);
	$update_main_queries[] = update_option('woo_language_carts11', $woo_language_carts11);
	$update_main_queries[] = update_option('woo_language_carts12', $woo_language_carts12);

	} 
	
	
	 $i = 0;
	 $text = '';
	 
	 
	 foreach($update_main_queries as $update_main_query) {
		if($update_main_query) {
			$text = '<font color="green"> 更新成功！</font><br />';
		}
		$i++;
	}
	if(empty($text)) {
		$text = '<font color="red">您对设置没有做出任何改动...</font>';
	}
	
}


$woo_language_wh1 = get_option('woo_language_wh1');
$woo_language_wh3 = get_option('woo_language_wh3');
$woo_language_wh4 = get_option('woo_language_wh4');
$woo_language_wh5 = get_option('woo_language_wh5');


$woo_language_l1 = get_option('woo_language_l1');
$woo_language_l2 = get_option('woo_language_l2');
$woo_language_l3 = get_option('woo_language_l3');
$woo_language_l4 = get_option('woo_language_l4');
$woo_language_l5 = get_option('woo_language_l5');
$woo_language_l6 = get_option('woo_language_l6');
$woo_language_l7 = get_option('woo_language_l7');
$woo_language_l8 = get_option('woo_language_l8');

$woo_language_r1 = get_option('woo_language_r1');
$woo_language_r2 = get_option('woo_language_r2');
$woo_language_r3 = get_option('woo_language_r3');
$woo_language_r4 = get_option('woo_language_r4');

$woo_language_f1 = get_option('woo_language_f1');
$woo_language_f2 = get_option('woo_language_f2');
$woo_language_f3 = get_option('woo_language_f3');
$woo_language_f4 = get_option('woo_language_f4');
$woo_language_f5 = get_option('woo_language_f5');
$woo_language_f6 = get_option('woo_language_f6');
$woo_language_f7 = get_option('woo_language_f7');
$woo_language_f8 = get_option('woo_language_f8');

$woo_language_p1 = get_option('woo_language_p1');
$woo_language_p2 = get_option('woo_language_p2');
$woo_language_p3 = get_option('woo_language_p3');
$woo_language_p4 = get_option('woo_language_p4');
$woo_language_p5 = get_option('woo_language_p5');
$woo_language_p6 = get_option('woo_language_p6');
$woo_language_p7 = get_option('woo_language_p7');

$woo_language_d1 = get_option('woo_language_d1');
$woo_language_d2 = get_option('woo_language_d2');
$woo_language_d3 = get_option('woo_language_d3');
$woo_language_d4 = get_option('woo_language_d4');
$woo_language_d5 = get_option('woo_language_d5');
$woo_language_d6 = get_option('woo_language_d6');
$woo_language_d7 = get_option('woo_language_d7');
$woo_language_d8 = get_option('woo_language_d8');
$woo_language_d9 = get_option('woo_language_d9');
$woo_language_d0 = get_option('woo_language_d0');
$woo_language_d11 = get_option('woo_language_d11');
$woo_language_d12 = get_option('woo_language_d12');

$woo_language_ds1 = get_option('woo_language_ds1');
$woo_language_ds2 = get_option('woo_language_ds2');
$woo_language_ds3 = get_option('woo_language_ds3');
$woo_language_ds4 = get_option('woo_language_ds4');
$woo_language_ds5 = get_option('woo_language_ds5');
$woo_language_ds6 = get_option('woo_language_ds6');

$woo_language_dz1 = get_option('woo_language_dz1');
$woo_language_dz2 = get_option('woo_language_dz2');
$woo_language_dz3 = get_option('woo_language_dz3');
$woo_language_dz4 = get_option('woo_language_dz4');
$woo_language_dz5 = get_option('woo_language_dz5');
$woo_language_dz6 = get_option('woo_language_dz6');
$woo_language_dz7 = get_option('woo_language_dz7');
$woo_language_dz8 = get_option('woo_language_dz8');
$woo_language_dz9 = get_option('woo_language_dz9');
$woo_language_dz0 = get_option('woo_language_dz0');
$woo_language_dz11 = get_option('woo_language_dz11');
$woo_language_dz12 = get_option('woo_language_dz12');
$woo_language_dz13 = get_option('woo_language_dz13');
$woo_language_dz14 = get_option('woo_language_dz14');
$woo_language_dz15 = get_option('woo_language_dz15');
$woo_language_dz16 = get_option('woo_language_dz16');
$woo_language_dz17 = get_option('woo_language_dz17');
$woo_language_dz18 = get_option('woo_language_dz18');

$woo_language_or1 = get_option('woo_language_or1');
$woo_language_or2 = get_option('woo_language_or2');
$woo_language_or3 = get_option('woo_language_or3');
$woo_language_or4 = get_option('woo_language_or4');
$woo_language_or5 = get_option('woo_language_or5');
$woo_language_or6 = get_option('woo_language_or6');
$woo_language_or7 = get_option('woo_language_or7');
$woo_language_or8 = get_option('woo_language_or8');
$woo_language_or9 = get_option('woo_language_or9');

$woo_language_a1 = get_option('woo_language_a1');
$woo_language_a2 = get_option('woo_language_a2');
$woo_language_a3 = get_option('woo_language_a3');
$woo_language_a4 = get_option('woo_language_a4');
$woo_language_a5 = get_option('woo_language_a5');
$woo_language_a6 = get_option('woo_language_a6');
$woo_language_a7 = get_option('woo_language_a7');
$woo_language_a8 = get_option('woo_language_a8');
$woo_language_a9 = get_option('woo_language_a9');

$woo_language_cart1= get_option('woo_language_cart1');
$woo_language_cart2= get_option('woo_language_cart2');
$woo_language_cart3= get_option('woo_language_cart3');
$woo_language_cart4= get_option('woo_language_cart4');
$woo_language_cart5= get_option('woo_language_cart5');
$woo_language_cart6= get_option('woo_language_cart6');
$woo_language_cart7= get_option('woo_language_cart7');
$woo_language_cart8= get_option('woo_language_cart8');
$woo_language_cart9= get_option('woo_language_cart9');
$woo_language_cart0= get_option('woo_language_cart0');



$woo_language_carts1= get_option('woo_language_carts1');
$woo_language_carts2= get_option('woo_language_carts2');
$woo_language_carts3= get_option('woo_language_carts3');
$woo_language_carts4= get_option('woo_language_carts4');
$woo_language_carts5= get_option('woo_language_carts5');
$woo_language_carts6= get_option('woo_language_carts6');
$woo_language_carts7= get_option('woo_language_carts7');
$woo_language_carts8= get_option('woo_language_carts8');
$woo_language_carts9= get_option('woo_language_carts9');
$woo_language_carts0= get_option('woo_language_carts0');
$woo_language_carts11= get_option('woo_language_carts11');
$woo_language_carts12= get_option('woo_language_carts12');
theme_themepark_video('一些固定的文字可以在此处更改，若你想要让网站显示为其他语言，那么在此处可以对这些文字进行替换，woocommerce的一些语言需要使用语言包才能更改，这里只提供主题的一些固定文字，并有区域提示，对照区域进行替换或者翻译吧。');		

?>
<h3>woocommerce系统多语言替换</h3>
<?php if(!empty($text)) { echo '<!-- Last Action --><div id="message" class="updated fade"><p>'.$text.'</p></div>'; } ?>

  <form method="post" action="<?php echo admin_url('admin.php?page=woo_language_option'); ?>"class="xuanxiangka">
  <input type="hidden" size="60"  name="post_velue" value="yes"/>
  
  
  
  
  <table class="form-table">
      <tbody>
       <!-------------------------------title---------------------------------------------------------------->  
      <tr id="login">
               <th scope="row"><h2>登陆之后的问候语</h2>
                </th>
                <td>
               
                </td>
            </tr>
      <tr>
       <th scope="row"><label for="woo_language_wh1">早上好！</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_wh1" id="woo_language_wh1" value="<?php echo $woo_language_wh1; ?>"/>  <br />

                 <p>登陆之后个人中心的问候语会根据时间显示不同的问候语</p>
                </td>
            </tr>
            
        
            
             <tr>
       <th scope="row"><label for="woo_language_wh3">中午好！</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_wh3" id="woo_language_wh3" value="<?php echo $woo_language_wh3; ?>"/>  <br />

               <p>登陆之后个人中心的问候语会根据时间显示不同的问候语</p>
                </td>
            </tr>   
            
            
                 <tr>
       <th scope="row"><label for="woo_language_wh4">下午好！</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_wh4" id="woo_language_wh4" value="<?php echo $woo_language_wh4; ?>"/>  <br />

                 <p>登陆之后个人中心的问候语会根据时间显示不同的问候语</p>
                </td>
            </tr>  
            
            
            
                 <tr>
       <th scope="row"><label for="woo_language_wh5">晚上好！</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_wh5" id="woo_language_wh5" value="<?php echo $woo_language_wh5; ?>"/>  <br />

                 <p>登陆之后个人中心的问候语</p>
                </td>
            </tr>  
   
           
            </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submitxx" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
  
  
  
  
  
  
  <table class="form-table">
      <tbody>
       <!-------------------------------title---------------------------------------------------------------->  
      <tr id="login">
               <th scope="row"><h2>【登录页面】</h2>
                </th>
                <td>
               
                </td>
            </tr>
      <tr>
       <th scope="row"><label for="woo_language_l1">用户登录</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l1" id="woo_language_l1" value="<?php echo $woo_language_l1; ?>"/>  <br />

                 <p>登录注册时的切换文字</p>
                </td>
            </tr>
            
          <tr>  
          
          <th scope="row"><label for="woo_language_l2">用户注册</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l2" id="woo_language_l2" value="<?php echo $woo_language_l2; ?>"/>  <br />

                 <p>登录注册时的切换文字</p>
                </td>
            </tr>
            
          <tr>  
          
           <th scope="row"><label for="woo_language_l3">用户名或电邮地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l3" id="woo_language_l3" value="<?php echo $woo_language_l3; ?>"/>  <br />

                 <p>登录表单文字</p>
                </td>
            </tr>
            
          <tr> 
          
          
           <th scope="row"><label for="woo_language_l4">密码</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l4" id="woo_language_l4" value="<?php echo $woo_language_l4; ?>"/>  <br />

                 <p>登录表单文字</p>
                </td>
            </tr>
            
          <tr> 
          
          
           <th scope="row"><label for="woo_language_l5">记住我</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l5" id="woo_language_l5" value="<?php echo $woo_language_l5; ?>"/>  <br />

                 <p>登录表单文字</p>
                </td>
            </tr>
            
          
        
           <tr> 
           <th scope="row"><label for="woo_language_l6">忘记密码？</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l6" id="woo_language_l6" value="<?php echo $woo_language_l6; ?>"/>  <br />

                 <p>登录表单文字</p>
                </td>
            </tr>
            
            <tr> 
           <th scope="row"><label for="woo_language_l7">其他方式登录</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l7" id="woo_language_l7" value="<?php echo $woo_language_l7; ?>"/>  <br />

                 <p>如果你安装了社会化登录插件Open Social，那么登录处会出现社会化登录的图标，图标上文字可更改。</p>
                </td>
            </tr>
            
            
            <tr> 
           <th scope="row"><label for="woo_language_l8">立即登录</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_l8" id="woo_language_l8" value="<?php echo $woo_language_l8; ?>"/>  <br />

                 <p>登录按钮文字</p>
                </td>
            </tr>
           
            </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit1" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody> 
            
             <!-------------------------------re---------------------------------------------------------------->  
      <tr id="register">
               <th scope="row"><h2>【注册页面】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
           <tr> 
           <th scope="row"><label for="woo_language_r1">用户名</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_r1" id="woo_language_r1" value="<?php echo $woo_language_r1; ?>"/>  <br />

                 <p>注册界面文字</p>
                </td>
            </tr>
            
            
            <tr> 
           <th scope="row"><label for="woo_language_r2">电邮地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_r2" id="woo_language_r2" value="<?php echo $woo_language_r2; ?>"/>  <br />

                 <p>注册界面文字</p>
                </td>
            </tr>
            
             <tr> 
           <th scope="row"><label for="woo_language_r3">密码</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_r3" id="woo_language_r3" value="<?php echo $woo_language_r3; ?>"/>  <br />

                 <p>注册按钮文字</p>
                </td>
            </tr>
            
            
              <th scope="row"><label for="woo_language_r4">注册</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_r4" id="woo_language_r4" value="<?php echo $woo_language_r4; ?>"/>  <br />

                 <p>注册按钮文字</p>
                </td>
            </tr>
          
             </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit2" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody> 
          
                   <!-------------------------------forgotpassword---------------------------------------------------------------->  
      <tr id="forgotpassword">
               <th scope="row"><h2>【忘记密码页面】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
           <tr> 
           <th scope="row"><label for="woo_language_f1">忘记密码提示文字</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f1" id="woo_language_f1" value="<?php echo $woo_language_f1; ?>"/>  <br />

                 <p>默认文字为：忘记密码了？请输入您的用户名或电邮地址。您将会收到一封带有重置密码链接的邮件。</p>
                </td>
            </tr>
            
            <tr> 
           <th scope="row"><label for="woo_language_f2">用户名或电子邮件</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f2" id="woo_language_f2" value="<?php echo $woo_language_f2; ?>"/>  <br />

                 <p>忘记密码提示文字</p>
                </td>
            </tr>
            
            
            <tr> 
           <th scope="row"><label for="woo_language_f3">密码重置</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f3" id="woo_language_f3" value="<?php echo $woo_language_f3; ?>"/>  <br />

                 <p>密码重置按钮</p>
                </td>
            </tr>
          
          
          
           <tr> 
           <th scope="row"><label for="woo_language_f4">在下面输入新密码</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f4" id="woo_language_f4" value="<?php echo $woo_language_f4; ?>"/>  <br />

                 <p>重设密码提示</p>
                </td>
            </tr>
            
            
            
           <tr> 
           <th scope="row"><label for="woo_language_f5">新密码</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f5" id="woo_language_f5" value="<?php echo $woo_language_f5; ?>"/>  <br />

                 <p>重设密码提示</p>
                </td>
            </tr>
            
            
                 
           <tr> 
           <th scope="row"><label for="woo_language_f6">再次输入</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f6" id="woo_language_f6" value="<?php echo $woo_language_f6; ?>"/>  <br />

                 <p>重设密码提示</p>
                </td>
            </tr>
            
            
                    
         
          
          
                 
           <tr> 
           <th scope="row"><label for="woo_language_f7">保存</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f7" id="woo_language_f7" value="<?php echo $woo_language_f7; ?>"/>  <br />

                 <p>重设密码按钮</p>
                </td>
            </tr>
          
            <tr> 
           <th scope="row"><label for="woo_language_f8">原密码</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_f8" id="woo_language_f8" value="<?php echo $woo_language_f8; ?>"/>  <br />

                 <p>个人中心中修改密码时的原密码提示</p>
                </td>
            </tr>
          
          
          </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit3" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody>  
             
      <!-------------------------------person---------------------------------------------------------------->  
      <tr id="person">
               <th scope="row"><h2>【个人中心左侧导航】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
           <tr> 
           <th scope="row"><label for="woo_language_p1">我的个人中心</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_p1" id="woo_language_p1" value="<?php echo $woo_language_p1; ?>"/>  <br />

                 <p>个人中心左侧的导航菜单标题</p>
                </td>
            </tr>
             <tr> 
             <th scope="row"><label for="woo_language_p2">资料概览</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_p2" id="woo_language_p2" value="<?php echo $woo_language_p2; ?>"/>  <br />

                 <p>个人中心左侧的导航菜单项目</p>
                </td>
            </tr>
          
           <tr> 
             <th scope="row"><label for="woo_language_p3">我的订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_p3" id="woo_language_p3" value="<?php echo $woo_language_p3; ?>"/>  <br />

                 <p>个人中心左侧的导航菜单项目</p>
                </td>
            </tr>
           <tr> 
           <th scope="row"><label for="woo_language_p4">我的下载</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_p4" id="woo_language_p4" value="<?php echo $woo_language_p4; ?>"/>  <br />

                 <p>个人中心左侧的导航菜单项目</p>
                </td>
            </tr>
            
              <tr> 
                     <th scope="row"><label for="woo_language_p5">收货地址</label>
                     </th>
                     <td>
                     <input  type="text" size="60"  name="woo_language_p5" id="woo_language_p5" value="<?php echo $woo_language_p5; ?>"/>  <br />

                     <p>个人中心左侧的导航菜单项目</p>
                     </td>
            </tr>
            
            
             <tr> 
                     <th scope="row"><label for="woo_language_p6">我的资料</label>
                     </th>
                     <td>
                     <input  type="text" size="60"  name="woo_language_p6" id="woo_language_p6" value="<?php echo $woo_language_p6; ?>"/>  <br />

                     <p>个人中心左侧的导航菜单项目</p>
                     </td>
            </tr>
            
             <tr> 
                     <th scope="row"><label for="woo_language_p7">退出登录</label>
                     </th>
                     <td>
                     <input  type="text" size="60"  name="woo_language_p7" id="woo_language_p7" value="<?php echo $woo_language_p7; ?>"/>  <br />

                     <p>个人中心左侧的导航菜单项目</p>
                     </td>
            </tr>
          
           </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit4" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody> 
          
          
      <!---------------------------------------person-orders-------------------------------------------------------->  
      <tr id="person-orders">
               <th scope="row"><h2>【订单状态】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
           <tr> 
           <th scope="row"><label for="woo_language_d1">全部订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d1" id="woo_language_d1" value="<?php echo $woo_language_d1; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
            
             <tr> 
           <th scope="row"><label for="woo_language_d2">未完成的订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d2" id="woo_language_d2" value="<?php echo $woo_language_d2; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
            
            
             <tr> 
           <th scope="row"><label for="woo_language_d3">已经发货</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d3" id="woo_language_d3" value="<?php echo $woo_language_d3; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
            
               <tr> 
           <th scope="row"><label for="woo_language_d4">正在处理</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d4" id="woo_language_d4" value="<?php echo $woo_language_d4; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
          
              <tr> 
           <th scope="row"><label for="woo_language_d5">已退款</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d5" id="woo_language_d5" value="<?php echo $woo_language_d5; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
            
             <tr> 
           <th scope="row"><label for="woo_language_d6">已完成</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d6" id="woo_language_d6" value="<?php echo $woo_language_d6; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
            
              <tr> 
           <th scope="row"><label for="woo_language_d7">我的购物车</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d7" id="woo_language_d7" value="<?php echo $woo_language_d7; ?>"/>  <br />

                 <p>个人中心中的订单状态切换按钮项目</p>
                </td>
            </tr>
          
          
          
            
           <tr> 
           <th scope="row"><label for="woo_language_d8">状态：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d8" id="woo_language_d8" value="<?php echo $woo_language_d8; ?>"/>  <br />

                 <p>订单列表中的订单状态</p>
                </td>
            </tr>
            
             <tr> 
           <th scope="row"><label for="woo_language_d9">待付款</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d9" id="woo_language_d9" value="<?php echo $woo_language_d9; ?>"/>  <br />

                 <p>订单列表中的订单状态</p>
                </td>
            </tr>
            
            
            
               <tr> 
           <th scope="row"><label for="woo_language_d0">已取消</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d0" id="woo_language_d0" value="<?php echo $woo_language_d0; ?>"/>  <br />

                 <p>订单列表中的订单状态</p>
                </td>
            </tr>
            
            <tr> 
           <th scope="row"><label for="woo_language_d11">保留</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d11" id="woo_language_d11" value="<?php echo $woo_language_d11; ?>"/>  <br />

                 <p>订单列表中的订单状态</p>
                </td>
            </tr>
            
           
             <tr> 
           <th scope="row"><label for="woo_language_d12">失败订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_d12" id="woo_language_d12" value="<?php echo $woo_language_d12; ?>"/>  <br />

                 <p>订单列表中的订单状态</p>
                </td>
            </tr>
        
         </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit5" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody> 
          <!--------------------------------------------ordersp1--------------------------------------------------->  
      <tr id="ordersp1">
               <th scope="row"><h2>【订单详细文字】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
           <tr> 
           <th scope="row"><label for="woo_language_ds1">订单号：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds1" id="woo_language_ds1" value="<?php echo $woo_language_ds1; ?>"/>  <br />

                 <p>个人中心中的订单状态的一些其他文字</p>
                </td>
            </tr>    
            
            <tr> 
           <th scope="row"><label for="woo_language_ds2">联系客服</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds2" id="woo_language_ds2" value="<?php echo $woo_language_ds2; ?>"/>  <br />

                 <p>联系客服的链接设置在自定义--woocommerce模板风格--联系在线客服自定义链接，若没有填写链接则不显示</p>
                </td>
            </tr>    
          
          
           <tr> 
           <th scope="row"><label for="woo_language_ds3">订单详细</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds3" id="woo_language_ds3" value="<?php echo $woo_language_ds3; ?>"/>  <br />

                 <p>个人中心中的订单状态的一些其他文字</p>
                </td>
            </tr>    
            
            
            <tr> 
           <th scope="row"><label for="woo_language_ds5">现在支付</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds5" id="woo_language_ds5" value="<?php echo $woo_language_ds5; ?>"/>  <br />

                 <p>当订单状态为“待付款时”，会显示现在支付按钮，点击进入支付。</p>
                </td>
            </tr>    
            
            
              <tr> 
           <th scope="row"><label for="woo_language_ds6">取消订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds6" id="woo_language_ds6" value="<?php echo $woo_language_ds6; ?>"/>  <br />

                 <p>当订单状态为“待付款时”，可以取消订单</p>
                </td>
            </tr>    
            
          
           <tr> 
           <th scope="row"><label for="woo_language_ds4">个商品，总计：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_ds4" id="woo_language_ds4" value="<?php echo $woo_language_ds4; ?>"/>  <br />

                 <p>个人中心中的订单状态的一些其他文字</p>
                </td>
            </tr>   
             </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit6" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
           
           
           <table class="form-table">
      <tbody> 
               <!--------------------------------------------ordersp1--------------------------------------------------->  
      <tr id="ordersp1">
               <th scope="row"><h2>【订单详细流程】</h2>
                </th>
                <td>
               
                </td>
            </tr>
            
            
            
            
             <tr> 
           <th scope="row"><label for="woo_language_dz1">提交于</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz1" id="woo_language_dz1" value="<?php echo $woo_language_dz1; ?>"/>  <br />

                 <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
              <tr> 
           <th scope="row"><label for="woo_language_dz2">当前状态为</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz2" id="woo_language_dz2" value="<?php echo $woo_language_dz2; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>  
            
            
                <tr> 
           <th scope="row"><label for="woo_language_dz3">提交订单成功</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz3" id="woo_language_dz3" value="<?php echo $woo_language_dz3; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
                <tr> 
           <th scope="row"><label for="woo_language_dz4">等待付款</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz4" id="woo_language_dz4" value="<?php echo $woo_language_dz4; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_dz5">货到付款</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz5" id="woo_language_dz5" value="<?php echo $woo_language_dz5; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_dz6">付款成功</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz6" id="woo_language_dz6" value="<?php echo $woo_language_dz6; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_dz7">保留订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz7" id="woo_language_dz7" value="<?php echo $woo_language_dz7; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
           
           
              <tr> 
           <th scope="row"><label for="woo_language_dz8">订单失败</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz8" id="woo_language_dz8" value="<?php echo $woo_language_dz8; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
            
              <tr> 
           <th scope="row"><label for="woo_language_dz9">正在处理</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz9" id="woo_language_dz9" value="<?php echo $woo_language_dz9; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
               <tr> 
           <th scope="row"><label for="woo_language_dz0">已经发货</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz0" id="woo_language_dz0" value="<?php echo $woo_language_dz0; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>   
            
            
                <tr> 
           <th scope="row"><label for="woo_language_dz11">暂未发货</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz11" id="woo_language_dz11" value="<?php echo $woo_language_dz11; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
            
                <tr> 
           <th scope="row"><label for="woo_language_dz12">暂未评分</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz12" id="woo_language_dz12" value="<?php echo $woo_language_dz12; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_dz13">已经评分</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz13" id="woo_language_dz13" value="<?php echo $woo_language_dz13; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
             <tr> 
           <th scope="row"><label for="woo_language_dz14">订单完成</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz14" id="woo_language_dz14" value="<?php echo $woo_language_dz14; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
              <tr> 
           <th scope="row"><label for="woo_language_dz15">订单未完成</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz15" id="woo_language_dz15" value="<?php echo $woo_language_dz15; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
              <tr> 
           <th scope="row"><label for="woo_language_dz16">查询物流</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz16" id="woo_language_dz16" value="<?php echo $woo_language_dz16; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
          
          
          
              <tr> 
           <th scope="row"><label for="woo_language_dz17">订单信息更新</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz17" id="woo_language_dz17" value="<?php echo $woo_language_dz17; ?>"/>  <br />

                <p>个人中心中的订单状态流程</p>
                </td>
            </tr>    
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_dz18">未完成的订单没有项目时</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_dz18" id="woo_language_dz18" value="<?php echo $woo_language_dz18; ?>"/>  <br />
                <p>在个人中心--仪表盘中，如果没有未完成的订单则显示提示：近期还没有未完成的订单哦，你可以查看全部全部订单，或者去购物车结算。</p>
                </td>
            </tr>    
          
      
      </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit7" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
  
     <table class="form-table">
      <tbody> 
          
          
      <!---------------------------------------person-orders-------------------------------------------------------->  
      <tr id="person-orders">
               <th scope="row"><h2>【订单详细表单】</h2>
                </th>
                <td>
               
                </td>
            </tr>
  
  
     <tr> 
           <th scope="row"><label for="woo_language_or1">商品</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or1" id="woo_language_or1" value="<?php echo $woo_language_or1; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
            <tr> 
           <th scope="row"><label for="woo_language_or2">合计</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or2" id="woo_language_or2" value="<?php echo $woo_language_or2; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
            <tr> 
           <th scope="row"><label for="woo_language_or3">我的评价</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or3" id="woo_language_or3" value="<?php echo $woo_language_or3; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
  
  
             <tr> 
           <th scope="row"><label for="woo_language_or4">评价商品</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or4" id="woo_language_or4" value="<?php echo $woo_language_or4; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
  
  
  
           <tr> 
           <th scope="row"><label for="woo_language_or5">购物小计：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or5" id="woo_language_or5" value="<?php echo $woo_language_or5; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
            
             <tr> 
           <th scope="row"><label for="woo_language_or6">配送:</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or6" id="woo_language_or6" value="<?php echo $woo_language_or6; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
             <tr> 
           <th scope="row"><label for="woo_language_or7">付款方式：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or7" id="woo_language_or7" value="<?php echo $woo_language_or7; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
            
            
            
             <tr> 
           <th scope="row"><label for="woo_language_or8">再次下单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_or8" id="woo_language_or8" value="<?php echo $woo_language_or8; ?>"/>  <br />

                <p>订单详细表单中的文字</p>
                </td>
            </tr>  
            
           
           
           
            
             
  
   </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit8" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
        
        
        
        
          <table class="form-table">
      <tbody> 
          
          
      <!---------------------------------------person-orders-------------------------------------------------------->  
      <tr id="person-orders">
               <th scope="row"><h2>【个人中心其他语言】</h2>
                </th>
                <td>
               
                </td>
            </tr>
        
        
          <tr> 
           <th scope="row"><label for="woo_language_a1">特色推荐</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a1" id="woo_language_a1" value="<?php echo $woo_language_a1; ?>"/>  <br />

                <p>个人中心的界面有一个特色推荐，会显示特色产品（在产品页面的星标产品）</p>
                </td>
            </tr>  
        
          <tr> 
           <th scope="row"><label for="woo_language_a2">下载</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a2" id="woo_language_a2" value="<?php echo $woo_language_a2; ?>"/>  <br />

                <p>个人中心的下载标题</p>
                </td>
            </tr>  
        
        
          <tr> 
           <th scope="row"><label for="woo_language_a3">没有下载项目时的提示</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a3" id="woo_language_a3" value="<?php echo $woo_language_a2; ?>"/>  <br />

                <p>原文为：还没有可下载的数据哦，你可以查看全部全部订单，或者去购物车结算</p>
                </td>
            </tr>  
        
        
        
        
          <tr> 
           <th scope="row"><label for="woo_language_a4">查看全部订单</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a4" id="woo_language_a4" value="<?php echo $woo_language_a4; ?>"/>  <br />

                <p>当现在项目还不存在时，会显示两个按钮</p>
                </td>
            </tr>  
            
            
            
          <tr> 
           <th scope="row"><label for="woo_language_a5">进入购物车</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a5" id="woo_language_a5" value="<?php echo $woo_language_a5; ?>"/>  <br />

                <p>当现在项目还不存在时，会显示两个按钮</p>
                </td>
            </tr>  
            
            
           <tr> 
           <th scope="row"><label for="woo_language_a6">我的地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a6" id="woo_language_a6" value="<?php echo $woo_language_a6; ?>"/>  <br />

                <p>我的地址</p>
                </td>
            </tr>  
            
            
                <tr> 
           <th scope="row"><label for="woo_language_a7">账单地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a7" id="woo_language_a7" value="<?php echo $woo_language_a7; ?>"/>  <br />

                <p>当有下载项目时，表单上的标题</p>
                </td>
            </tr>  
            
            
             <tr> 
           <th scope="row"><label for="woo_language_a8">配送地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a8" id="woo_language_a8" value="<?php echo $woo_language_a8; ?>"/>  <br />

                <p>当有下载项目时，表单上的标题</p>
                </td>
            </tr>  
            
            
            
             
             <tr> 
           <th scope="row"><label for="woo_language_a9">地址提示文字</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_a9" id="woo_language_a9" value="<?php echo $woo_language_a9; ?>"/>  <br />

                <p>原文提示为：下列地址将默认用于结算页面。</p>
                </td>
            </tr>  
            
        
        
        </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit9" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
        
        
        
        
           <!---------------------------------------person-orders-------------------------------------------------------->  
           
               <table class="form-table">
      <tbody> 
      <tr id="cart">
               <th scope="row"><h2>【购物车语言替换】</h2>
                </th>
                <td>
               
                </td>
            </tr>
        
        
             
             <tr> 
           <th scope="row"><label for="woo_language_cart1">一共有</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart1" id="woo_language_cart1" value="<?php echo $woo_language_cart1; ?>"/>  <br />

                <p>购物车数量提示，原文为：一共有 x 件商品在购物车</p>
                </td>
            </tr>  
            
            
              <tr> 
           <th scope="row"><label for="woo_language_cart2">件商品在购物车</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart2" id="woo_language_cart2" value="<?php echo $woo_language_cart2; ?>"/>  <br />

                <p>购物车数量提示，原文为：一共有 x 件商品在购物车</p>
                </td>
            </tr>  
            
            
              
              <tr> 
           <th scope="row"><label for="woo_language_cart3">您的购物车目前是空的。</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart3" id="woo_language_cart3" value="<?php echo $woo_language_cart3; ?>"/>  <br />

                <p>当购物车为空时的提示。</p>
                </td>
            </tr>  
            
            
                  
              <tr> 
           <th scope="row"><label for="woo_language_cart4">去选购商品吧！</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart4" id="woo_language_cart4" value="<?php echo $woo_language_cart4; ?>"/>  <br />

                <p>当购物车为空时，提示用户去商品页面</p>
                </td>
            </tr>  
            
            
               <tr> 
           <th scope="row"><label for="woo_language_cart5">价格</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart5" id="woo_language_cart5" value="<?php echo $woo_language_cart5; ?>"/>  <br />

                <p>购物车表格上的价格</p>
                </td>
            </tr>  
            
            
             
               <tr> 
           <th scope="row"><label for="woo_language_cart6">数量</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart6" id="woo_language_cart6" value="<?php echo $woo_language_cart6; ?>"/>  <br />

                <p>购物车表格上的数量</p>
                </td>
            </tr>  
            
            
                <tr> 
           <th scope="row"><label for="woo_language_cart7">操作</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart7" id="woo_language_cart7" value="<?php echo $woo_language_cart7; ?>"/>  <br />

                <p>购物车表格上的操作</p>
                </td>
            </tr>  
            
            
             
                <tr> 
           <th scope="row"><label for="woo_language_cart8">使用优惠券</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart8" id="woo_language_cart8" value="<?php echo $woo_language_cart8; ?>"/>  <br />

                <p>使用优惠券按钮</p>
                </td>
            </tr>  
            
                <tr> 
           <th scope="row"><label for="woo_language_cart9">更新购物车</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart9" id="woo_language_cart9" value="<?php echo $woo_language_cart9; ?>"/>  <br />

                <p>更新购物车按钮</p>
                </td>
            </tr>  
            
               <tr> 
           <th scope="row"><label for="woo_language_cart0">移除商品</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_cart0" id="woo_language_cart0" value="<?php echo $woo_language_cart0; ?>"/>  <br />

                <p>移除商品链接文字</p>
                </td>
            </tr>  
        
        
        </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit0" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
        
        
        
           
           <!---------------------------------------chackout-------------------------------------------------------->  
           
               <table class="form-table">
      <tbody> 
      <tr id="chackout">
               <th scope="row"><h2>【购物车和结算】</h2>
                </th>
                <td>
               
                </td>
            </tr>
        
        
             
             <tr> 
           <th scope="row"><label for="woo_language_carts1">购物车总计</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts1" id="woo_language_carts1" value="<?php echo $woo_language_carts1; ?>"/>  <br />

                <p>购物车总计标题</p>
                </td>
            </tr>  
            
            
            
               
             <tr> 
           <th scope="row"><label for="woo_language_carts2">小计</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts2" id="woo_language_carts2" value="<?php echo $woo_language_carts2; ?>"/>  <br />

                <p>购物车总计表格</p>
                </td>
            </tr>  
            
            
               
               
             <tr> 
           <th scope="row"><label for="woo_language_carts3">配送</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts3" id="woo_language_carts3" value="<?php echo $woo_language_carts3; ?>"/>  <br />

                <p>购物车总计表格</p>
                </td>
            </tr>  
            
            
                 <tr> 
           <th scope="row"><label for="woo_language_carts4">现在去结算</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts4" id="woo_language_carts4" value="<?php echo $woo_language_carts4; ?>"/>  <br />

                <p>购物车内结算按钮</p>
                </td>
            </tr>  
            
            
             
                 <tr> 
           <th scope="row"><label for="woo_language_carts5">收货人详情</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts5" id="woo_language_carts5" value="<?php echo $woo_language_carts5; ?>"/>  <br />

                <p>结算处调用的默认收货人信息标题</p>
                </td>
            </tr>  
            
             
                 <tr> 
           <th scope="row"><label for="woo_language_carts6">收货人姓名：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts6" id="woo_language_carts6" value="<?php echo $woo_language_carts6; ?>"/>  <br />

                <p>结算处调用收货人信息</p>
                </td>
            </tr>  
            
             <tr> 
           <th scope="row"><label for="woo_language_carts7">收货人电话：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts7" id="woo_language_carts7" value="<?php echo $woo_language_carts7; ?>"/>  <br />

                <p>结算处调用收货人信息</p>
                </td>
            </tr>  
            
              <tr> 
           <th scope="row"><label for="woo_language_carts8">配送地址：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts8" id="woo_language_carts8" value="<?php echo $woo_language_carts8; ?>"/>  <br />

                <p>结算处调用收货人信息</p>
                </td>
            </tr>  
            
              <tr> 
           <th scope="row"><label for="woo_language_carts9">邮编：</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts9" id="woo_language_carts9" value="<?php echo $woo_language_carts9; ?>"/>  <br />

                <p>结算处调用收货人信息</p>
                </td>
            </tr>  
            
            
              <tr> 
           <th scope="row"><label for="woo_language_carts0">修改地址</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts0" id="woo_language_carts0" value="<?php echo $woo_language_carts0; ?>"/>  <br />

                <p>结算处调用收货人信息</p>
                </td>
            </tr>  
            
            
            
              <tr> 
           <th scope="row"><label for="woo_language_carts11">我已经阅读并接受</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts11" id="woo_language_carts11" value="<?php echo $woo_language_carts11; ?>"/>  <br />

                <p>条款说明替换</p>
                </td>
            </tr>  
            
            
            
              <tr> 
           <th scope="row"><label for="woo_language_carts12"> 条款及条件</label>
                </th>
                <td>
               <input  type="text" size="60"  name="woo_language_carts12" id="woo_language_carts12" value="<?php echo $woo_language_carts12; ?>"/>  <br />

                <p>条款说明替换</p>
                </td>
            </tr>  
            
            
          </tbody>
      </table>
     <table> <tr>
        <td><p class="submit">
      
            <input type="submit" name="Submit11" value="提交" class="button-primary"/>
           
            </p>
        </td>

        </tr> </table>
        
        
        
  </form>


<?php }?>